package com.example.wagner_project2;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.BaseAdapter;
import java.util.List;

public class WeightAdapter extends BaseAdapter {
    private Context context;
    private List<String> weightLogs;
    private WeightDatabaseHelper dbHelper;
    private OnDataChangedListener dataChangedListener;
    private OnItemSelectedListener itemSelectedListener;
    private String loggedInUsername; // Store the logged-in username

    // Interface for data change notification
    public interface OnDataChangedListener {
        void onDataChanged();
    }

    // Interface for selecting an item to update
    public interface OnItemSelectedListener {
        void onItemSelected(int id, String date, double weight);
        void onItemDeleted(int id); // Notify when an item is deleted
    }

    public WeightAdapter(Context context, List<String> weightLogs, WeightDatabaseHelper dbHelper,
                         String loggedInUsername, OnDataChangedListener listener, OnItemSelectedListener selectedListener) {
        this.context = context;
        this.weightLogs = weightLogs;
        this.dbHelper = dbHelper;
        this.loggedInUsername = loggedInUsername; // Assign logged-in username
        this.dataChangedListener = listener;
        this.itemSelectedListener = selectedListener;
    }

    @Override
    public int getCount() {
        return weightLogs.size();
    }

    @Override
    public Object getItem(int position) {
        return weightLogs.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.weight_item, parent, false);
        }

        TextView weightText = convertView.findViewById(R.id.weightText);
        Button deleteButton = convertView.findViewById(R.id.deleteButton);

        String log = weightLogs.get(position);
        weightText.setText(log);

        // Extract Date and Weight (Since ID is removed)
        String[] parts = log.split(" \\| ");
        String date = parts[0].split(": ")[1].trim();
        double weight = Double.parseDouble(parts[1].split(": ")[1].replace(" lbs", "").trim());

        // Find the actual ID in the database (instead of extracting from log)
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM weight_logs WHERE date = ? AND weight = ? AND username = ?",
                new String[]{date, String.valueOf(weight), loggedInUsername});

        int weightId = -1;
        if (cursor.moveToFirst()) {
            weightId = cursor.getInt(0);
        }
        cursor.close();

        int finalWeightId = weightId; // Required for lambda expression
        convertView.setOnClickListener(v -> {
            if (finalWeightId != -1) {
                itemSelectedListener.onItemSelected(finalWeightId, date, weight);
            }
        });

        deleteButton.setOnClickListener(v -> {
            if (finalWeightId != -1) {
                boolean deleted = dbHelper.deleteWeight(finalWeightId, loggedInUsername); // FIXED: Pass username
                if (deleted) {
                    Toast.makeText(context, "Weight deleted!", Toast.LENGTH_SHORT).show();
                    dataChangedListener.onDataChanged();
                    itemSelectedListener.onItemDeleted(finalWeightId);
                } else {
                    Toast.makeText(context, "Delete failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return convertView;
    }
}
