package com.example.wagner_project2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class HomeActivity extends AppCompatActivity implements WeightAdapter.OnDataChangedListener, WeightAdapter.OnItemSelectedListener {
    private static final int SMS_PERMISSION_REQUEST_CODE = 101;

    private WeightDatabaseHelper dbHelper;
    private GridView weightGridView;
    private EditText dateInput, weightInput, phoneNumberInput, reminderMessageInput;
    private Button actionButton, sendReminderButton;
    private int selectedId = -1;
    private WeightAdapter adapter;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        dbHelper = new WeightDatabaseHelper(this);
        weightGridView = findViewById(R.id.weightGridView);
        dateInput = findViewById(R.id.dateInput);
        weightInput = findViewById(R.id.weightInput);
        phoneNumberInput = findViewById(R.id.phoneNumberInput);
        reminderMessageInput = findViewById(R.id.reminderMessageInput);
        actionButton = findViewById(R.id.actionButton);
        sendReminderButton = findViewById(R.id.sendReminderButton);

        username = getIntent().getStringExtra("USERNAME");
        if (username == null) username = "default_user";

        TextView greetingText = findViewById(R.id.greetingText);
        greetingText.setText("Hi, " + username + "!");

        Button logoutButton = findViewById(R.id.logoutButton);
        logoutButton.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, LoginActivity.class));
            finish();
        });

        checkSmsPermission();
        loadWeightData();

        // Handle adding or updating weight
        actionButton.setOnClickListener(v -> {
            String date = dateInput.getText().toString().trim();
            String weightText = weightInput.getText().toString().trim();

            if (date.isEmpty() || weightText.isEmpty()) {
                Toast.makeText(this, "Please enter date and weight", Toast.LENGTH_SHORT).show();
                return;
            }

            double weight = Double.parseDouble(weightText);

            if (selectedId == -1) {
                if (dbHelper.addWeight(username, date, weight)) {
                    Toast.makeText(this, "Weight added!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Failed to add weight", Toast.LENGTH_SHORT).show();
                }
            } else {
                if (dbHelper.updateWeight(selectedId, username, date, weight)) {
                    Toast.makeText(this, "Weight updated!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
                }
                resetForm();
            }

            loadWeightData();
        });

        // Handle sending SMS reminder
        sendReminderButton.setOnClickListener(v -> {
            String phoneNumber = phoneNumberInput.getText().toString().trim();
            String message = reminderMessageInput.getText().toString().trim();

            if (phoneNumber.isEmpty()) {
                Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show();
                return;
            }

            if (message.isEmpty()) {
                message = "Reminder: Enter your weight for the day!";
            }

            sendSmsNotification(phoneNumber, message);
        });
    }

    // Load weight data from the database
    private void loadWeightData() {
        List<String> logs = dbHelper.readWeightLogs(username);
        adapter = new WeightAdapter(this, logs, dbHelper, username, this, this);
        weightGridView.setAdapter(adapter);
    }

    // Reset input fields after adding or updating weight
    private void resetForm() {
        selectedId = -1;
        dateInput.setText("");
        weightInput.setText("");
        actionButton.setText("Add Weight");

        // Hide the keyboard
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }


    // Check SMS permission and request if not granted
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    // Handle SMS permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Send SMS notification
    private void sendSmsNotification(String phoneNumber, String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "Reminder Sent!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    // Refresh data when items change
    @Override
    public void onDataChanged() {
        loadWeightData();
    }

    // Handle item selection for updating weight
    @Override
    public void onItemSelected(int id, String date, double weight) {
        selectedId = id;
        dateInput.setText(date);
        weightInput.setText(String.valueOf(weight));
        actionButton.setText("Update Weight");
        Toast.makeText(this, "Selected for update", Toast.LENGTH_SHORT).show();
    }

    // Handle item deletion
    @Override
    public void onItemDeleted(int id) {
        if (selectedId == id) {
            resetForm();
        }
    }
}
